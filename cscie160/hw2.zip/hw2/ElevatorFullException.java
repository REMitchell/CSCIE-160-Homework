package cscie160.hw2;

public class ElevatorFullException extends Exception {

}
